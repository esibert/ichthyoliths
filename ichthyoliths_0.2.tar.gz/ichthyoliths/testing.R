##### Package install workflow #####
library(devtools)
library(roxygen2)

# devtools::document() - builds documentation
# shift + ctrl + B - builds the package

##### 6/5/2019 v0.2.1 testing the rangechart function #####
morphdat <- read.csv('../EO_Fish/data/EO_fish_csv_Feb11.csv', header = TRUE)
sub<-data.frame(morphdat$AgeID, morphdat$Morphotype_Name)
counts<-table(sub, exclude='')  #make occurrance table#
counts.df <- as.data.frame.matrix(counts)
counts.mat <- matrix(counts, nrow = 18, ncol = 65, byrow = FALSE)
rownames(counts.mat) <- rownames(counts)
colnames(counts.mat) <- colnames(counts)

rangechart(counts) #good
rangechart(counts, reorder = 'fad.by.lad') #good
rangechart(counts, reorder = 'fad.by.lad', xaxis.labels = 'alphanum', print.xaxis = TRUE) #good
rangechart(counts, reorder = 'fad.by.lad', xaxis.labels = 'alphanum',
           col.points = 'by.count', cols.vec = 'viridis', count.breaks = c(0, 2, 5, 10)) #good
rangechart(counts, reorder = 'lad.by.fad', xaxis.labels = 'alphanum',
           col.points = 'by.count', cols.vec = 'viridis', normalize.counts = TRUE,
           count.breaks = c(0, 2, 5, 10), cex.points = 'by.count') #good

# this used counts.mat without rownames or column names.
rangechart(counts.mat, ages = rownames(counts), taxa = colnames(counts),
           reorder = 'lad.by.fad', xaxis.labels = 'alphanum',
           col.points = 'by.count', cols.vec = 'viridis', normalize.counts = TRUE,
           count.breaks = c(0, 2, 5, 10), cex.points = 'by.count') #good

# test the age-ordering function:
age.scramble <- sample.int(18, 18)
counts <- counts[age.scramble,]
rangechart(counts, reorder = 'fad.by.lad', xaxis.labels = 'alphanum',
           col.points = 'by.count', cols.vec = 'viridis', normalize.counts = TRUE,
           count.breaks = c(0, 2, 5, 10),
           cex.points = 'by.count') #good

# test taxa categories
tax.categories <- c(rep(1, 20), rep(2, 45))

rangechart(counts, reorder = 'fad.by.lad', xaxis.labels = 'alphanum',
           col.points = 'by.count', cols.vec = 'viridis', normalize.counts = TRUE,
           count.breaks = c(0, 2, 5, 10), tax.cat = tax.categories,
           cex.points = 'by.count', pch.points = 'by.category', pch.vec = c(16, 17)) #good

# color by category
rangechart(counts, reorder = 'fad.by.lad', xaxis.labels = 'alphanum',
           col.points = 'by.category', cols.vec = 'viridis', normalize.counts = TRUE,
           count.breaks = c(0, 2, 5, 10), tax.cat = tax.categories,
           cex.points = 'by.count', pch.points = 'by.category', pch.vec = c(16, 17)) #good

# color by category, pch by count, cex = 1
rangechart(counts, reorder = 'fad.by.lad', xaxis.labels = 'alphanum',
           col.points = 'by.category', cols.vec = 'viridis', normalize.counts = TRUE,
           count.breaks = c(0, 2, 5, 10), tax.cat = tax.categories,
           cex.points = 'by.count', pch.points = 'by.count', pch.vec = c(15, 16, 17, 18)) #good


##### 5/9/2019 v0.2 testing and resetting things #####

### Traits object update
# call in new trait csv files
tooth_traits_v0.2 <- import_traits_csvs(csvpath = 'data/v0.2/traitCSV_teeth_v0.2/')
# save with new versions
save(tooth_traits_v0.2, file = 'data/v0.2/tooth_traits_v0.2.RData')

### Weights object update
tooth_weights_v0.2 <- c(rep(1,9), rep(0.5, 4), 1, .5, .5, 1,1,0.5, 0.5, 1, rep(0.5, 6))
# save it
save(tooth_weights_v0.2, file = 'data/v0.2/tooth_weights_v0.2.RData')


### update version names of old traits and weights objects
load('data/traits_v0.1.RData')
tooth_traits_v0.1 <- traits
save(tooth_traits_v0.1, file = 'data/v0.1/tooth_traits_v0.1.RData')

load('data/weights_v0.1.RData')
tooth_weights_v0.1 <- weights
save(tooth_weights_v0.1, file = 'data/v0.1/tooth_weights_v0.1.RData')


##### TESTING the new distances_clust function, Feb 2019 #####

library(devtools)
library(roxygen2)
library(doParallel)


## Call in Monica's dataset for quick playing...

dat_morph <- read.csv('../../modern-fish/csv/morphotypes_feb4.csv', skip = 1, header = TRUE)
dat_traits <- import_traits_csvs(csvpath = '../../modern-fish/traitCSV_Monica/')
dat_weights <- c(rep(1,8), rep(0.5, 4), 1, .5, .5, 1,1,0.5, 0.5, 1, rep(0.5, 6))
morphcols <- c(9:34) #call columns 9-34
idcol <- 6 #6th column of morphdat is what I want to have as the unique morphotype names in the output data frame
startcol <- 9 #9th column corresponds to the first column with a character in the traits list. This will not change regardless of the morphcols. Default is morphcols[1]

traits <- dat_traits
# save(traits, file = 'data/traits.RData')


morph <- dat_morph
traits <- dat_traits
weights <- dat_weights
morphCols <- morphcols
traitStartCol <- startcol
IDCol <- idcol
traitsStartCol <- startcol


## running the distance function
dat_distances <- distances_clust(morph = dat_morph, traits = dat_traits, weights = dat_weights,
                                 morphCols = morphcols, traitsStartCol = startcol, IDCol = idcol,
                                 subsetWeights = TRUE, contTraits = FALSE, coresFree=2)

# Troubleshooting - find the NAs...
df.na <- subset(dat_distances, is.na(dat_distances$dist.sum))

#list of teeth that broke the function (if any):
unique(df.na[,3])

# Once there are no more NA values, make the distance matrix object to calculate the morphospace
# make distmat
toothdistmat <- distmat(dat_distances)

dat_nmds <- metaMDS(toothdistmat, k=3)

# test the default value for traitsStartCol
dat_distances <- distances_clust(morph = dat_morph, traits = dat_traits, weights = dat_weights,
                                  morphCols = morphcols, IDCol = idcol,
                                  contTraits = FALSE, coresFree=2)


# test a subset of morph cols (lets say traits C, D1, D2, E1, F, G, H1, H3, K1, L)
morphcols <- c(9, 10, 11, 12, 14, 15, 16, 18, 21, 24)
names(dat_morph)[morphcols] #check tha these are the right subsets!

dat_distances <- distances_clust(morph = dat_morph, traits = dat_traits, weights = dat_weights,
                                 morphCols = morphcols, IDCol = idcol, subsetWeights = TRUE,
                                 contTraits = FALSE, coresFree=2)

df.na <- subset(dat_distances, is.na(dat_distances$dist.sum))
unique(df.na[,3])

dat_nmds <- metaMDS(toothdistmat, k=3)
plot(dat_nmds)
